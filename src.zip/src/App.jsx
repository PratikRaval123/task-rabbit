import { BrowserRouter, Route, Routes } from "react-router-dom";
import LandingPage from "./components/LadingPage";
import Service from "./components/Pages/Service";
import BecomeATester from "./components/Pages/BecomeATester";

const App = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/service" element={<Service />} />
        <Route path="/login" element={<LandingPage />} />
        <Route path="/becomeATester" element={<BecomeATester />} />
      </Routes>
    </BrowserRouter>
  );
};

export default App;
