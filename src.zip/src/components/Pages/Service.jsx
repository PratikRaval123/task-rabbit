import React from "react";
import styles from "../../style";
import Navbar from "../Navbar";

export default function Service() {
  const data = [
    {
      id: 1,
      name: "Featured Tasks",
      img: "https://res.cloudinary.com/taskrabbit-com/image/upload/q_auto,f_auto/v1597077996/dfzoq8osr6apr67tkynb.jpg",
      subItems: [
        { name: "Delivery" },
        { name: "Home Repairs" },
        { name: "General Cleaning" },
        { name: "Assemble Furniture" },
        { name: "Help Moving / Hauling" },
        { name: "Heavy Lifting" },
        { name: "Personal Assistant" },
        { name: "Yard Work" },
        { name: "Queue in Line" },
        { name: "Organize Closet" },
        { name: "Office Administration" },
        { name: "Organization" },
      ],
    },
    {
      id: 2,
      name: "Handyman",
      img: "https://res.cloudinary.com/taskrabbit-com/image/upload/q_auto,f_auto/v1597077996/dfzoq8osr6apr67tkynb.jpg",
      subItems: [
        { name: "Home Repairs" },
        { name: "Assemble Furniture" },
        { name: "TV Mounting" },
        { name: "Heavy Lifting" },
        { name: "Painting" },
        { name: "Plumbing" },
        { name: "Yard Work" },
        { name: "Hang Pictures" },
        { name: "Shelf Mounting" },
        { name: "Light Installation" },
        { name: "Electrical Work" },
        { name: "Carpentry" },
        { name: "Baby Proofing" },
        { name: "Smart Home Installation" },
      ],
    },
  ];

  return (
    <div className="bg-primary w-full overflow-hidden">
      <div className={`${styles.paddingX} ${styles.flexCenter}`}>
        <div className={`${styles.boxWidth}`}>
          <Navbar />
        </div>
      </div>
      <div className="flex flex-col ">
        {/* Hero Section */}
        <div className=" flex flex-col md:flex-row items-center justify-between  relative">
          <div className="text-center md:text-left absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
            <h1 className="text-3xl md:text-4xl font-bold mb-4">
              What do you need help with?
            </h1>
          </div>
          <div className="w-full">
            <img
              src="https://res.cloudinary.com/taskrabbit-com/image/upload/q_auto,f_auto/v1601487284/futujaglhmhwn0x7jfow.png"
              alt="Hero Section"
              className="h-full w-full object-cover"
            />
          </div>
        </div>
      </div>
      <div className={`${styles.boxWidth}`}>
        {/* Grid Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-8 ">
          {/* Featured Tasks */}
          {data?.map((ele) => {
            return (
              <div className="p-5 shadow-md rounded-md bg-gradient">
                <img
                  src={ele?.img}
                  alt="Featured Tasks"
                  className="w-full h-48 object-cover rounded-md mb-4"
                />
                <h2 className="text-xl font-bold mb-2 text-white">
                  {ele?.name}
                </h2>
                <div className="border-b border-gray-200 my-4"></div>

                {ele?.subItems?.map((item) => {
                  return (
                    <ul className="text-white space-y-2">
                      <li>{item?.name}</li>
                    </ul>
                  );
                })}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
