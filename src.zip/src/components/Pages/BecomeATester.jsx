import React from 'react'

export default function BecomeATester() {
  return (
    <div>BecomeATester</div>
  )
}
